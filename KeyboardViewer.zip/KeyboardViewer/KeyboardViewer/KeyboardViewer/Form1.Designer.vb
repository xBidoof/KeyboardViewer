﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Escape = New System.Windows.Forms.Button()
        Me.F1 = New System.Windows.Forms.Button()
        Me.F2 = New System.Windows.Forms.Button()
        Me.F4 = New System.Windows.Forms.Button()
        Me.F3 = New System.Windows.Forms.Button()
        Me.F8 = New System.Windows.Forms.Button()
        Me.F7 = New System.Windows.Forms.Button()
        Me.F6 = New System.Windows.Forms.Button()
        Me.F5 = New System.Windows.Forms.Button()
        Me.F12 = New System.Windows.Forms.Button()
        Me.F11 = New System.Windows.Forms.Button()
        Me.F10 = New System.Windows.Forms.Button()
        Me.F9 = New System.Windows.Forms.Button()
        Me.Pause = New System.Windows.Forms.Button()
        Me.Scroll = New System.Windows.Forms.Button()
        Me.PrintScreen = New System.Windows.Forms.Button()
        Me.Oem7 = New System.Windows.Forms.Button()
        Me.D1 = New System.Windows.Forms.Button()
        Me.D2 = New System.Windows.Forms.Button()
        Me.D3 = New System.Windows.Forms.Button()
        Me.D4 = New System.Windows.Forms.Button()
        Me.D5 = New System.Windows.Forms.Button()
        Me.D6 = New System.Windows.Forms.Button()
        Me.D7 = New System.Windows.Forms.Button()
        Me.D8 = New System.Windows.Forms.Button()
        Me.D9 = New System.Windows.Forms.Button()
        Me.D0 = New System.Windows.Forms.Button()
        Me.OemOpenBrackets = New System.Windows.Forms.Button()
        Me.Oemplus = New System.Windows.Forms.Button()
        Me.Back = New System.Windows.Forms.Button()
        Me.Insert = New System.Windows.Forms.Button()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Endd = New System.Windows.Forms.Button()
        Me.Home = New System.Windows.Forms.Button()
        Me.PageUp = New System.Windows.Forms.Button()
        Me.Nextt = New System.Windows.Forms.Button()
        Me.ReturnBig = New System.Windows.Forms.Button()
        Me.RShiftKey = New System.Windows.Forms.Button()
        Me.Oem1 = New System.Windows.Forms.Button()
        Me.Oem5 = New System.Windows.Forms.Button()
        Me.Oem6 = New System.Windows.Forms.Button()
        Me.P = New System.Windows.Forms.Button()
        Me.O = New System.Windows.Forms.Button()
        Me.I = New System.Windows.Forms.Button()
        Me.U = New System.Windows.Forms.Button()
        Me.Y = New System.Windows.Forms.Button()
        Me.T = New System.Windows.Forms.Button()
        Me.R = New System.Windows.Forms.Button()
        Me.E = New System.Windows.Forms.Button()
        Me.Z = New System.Windows.Forms.Button()
        Me.A = New System.Windows.Forms.Button()
        Me.Tab = New System.Windows.Forms.Button()
        Me.M = New System.Windows.Forms.Button()
        Me.Oemtilde = New System.Windows.Forms.Button()
        Me.L = New System.Windows.Forms.Button()
        Me.K = New System.Windows.Forms.Button()
        Me.J = New System.Windows.Forms.Button()
        Me.H = New System.Windows.Forms.Button()
        Me.G = New System.Windows.Forms.Button()
        Me.F = New System.Windows.Forms.Button()
        Me.D = New System.Windows.Forms.Button()
        Me.S = New System.Windows.Forms.Button()
        Me.Q = New System.Windows.Forms.Button()
        Me.Capital = New System.Windows.Forms.Button()
        Me.Oem8 = New System.Windows.Forms.Button()
        Me.OemQuestion = New System.Windows.Forms.Button()
        Me.OemPeriod = New System.Windows.Forms.Button()
        Me.Oemcomma = New System.Windows.Forms.Button()
        Me.N = New System.Windows.Forms.Button()
        Me.B = New System.Windows.Forms.Button()
        Me.V = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.Button()
        Me.X = New System.Windows.Forms.Button()
        Me.W = New System.Windows.Forms.Button()
        Me.OemBackslash = New System.Windows.Forms.Button()
        Me.LShiftKey = New System.Windows.Forms.Button()
        Me.LControlKey = New System.Windows.Forms.Button()
        Me.Up = New System.Windows.Forms.Button()
        Me.Left = New System.Windows.Forms.Button()
        Me.Down = New System.Windows.Forms.Button()
        Me.Right = New System.Windows.Forms.Button()
        Me.RControlKey = New System.Windows.Forms.Button()
        Me.Apps = New System.Windows.Forms.Button()
        Me.RWin = New System.Windows.Forms.Button()
        Me.RMenu = New System.Windows.Forms.Button()
        Me.LMenu = New System.Windows.Forms.Button()
        Me.LWin = New System.Windows.Forms.Button()
        Me.Space = New System.Windows.Forms.Button()
        Me.NumLock = New System.Windows.Forms.Button()
        Me.Divide = New System.Windows.Forms.Button()
        Me.Multiply = New System.Windows.Forms.Button()
        Me.Subtract = New System.Windows.Forms.Button()
        Me.NumPad7 = New System.Windows.Forms.Button()
        Me.NumPad8 = New System.Windows.Forms.Button()
        Me.NumPad9 = New System.Windows.Forms.Button()
        Me.Add = New System.Windows.Forms.Button()
        Me.NumPad6 = New System.Windows.Forms.Button()
        Me.NumPad3 = New System.Windows.Forms.Button()
        Me.Decimall = New System.Windows.Forms.Button()
        Me.NumPad5 = New System.Windows.Forms.Button()
        Me.NumPad2 = New System.Windows.Forms.Button()
        Me.NumPad0 = New System.Windows.Forms.Button()
        Me.NumPad4 = New System.Windows.Forms.Button()
        Me.NumPad1 = New System.Windows.Forms.Button()
        Me.Returnn = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.LeftMouseButton = New System.Windows.Forms.Button()
        Me.RightMouseButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.WheelButtonUp = New System.Windows.Forms.Button()
        Me.WheelButtonDown = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Escape
        '
        Me.Escape.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Escape.Location = New System.Drawing.Point(13, 20)
        Me.Escape.Margin = New System.Windows.Forms.Padding(4)
        Me.Escape.Name = "Escape"
        Me.Escape.Size = New System.Drawing.Size(60, 42)
        Me.Escape.TabIndex = 0
        Me.Escape.Text = "Esc"
        Me.Escape.UseVisualStyleBackColor = True
        '
        'F1
        '
        Me.F1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F1.Location = New System.Drawing.Point(116, 20)
        Me.F1.Margin = New System.Windows.Forms.Padding(4)
        Me.F1.Name = "F1"
        Me.F1.Size = New System.Drawing.Size(60, 42)
        Me.F1.TabIndex = 1
        Me.F1.Text = "F1"
        Me.F1.UseVisualStyleBackColor = True
        '
        'F2
        '
        Me.F2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F2.Location = New System.Drawing.Point(184, 20)
        Me.F2.Margin = New System.Windows.Forms.Padding(4)
        Me.F2.Name = "F2"
        Me.F2.Size = New System.Drawing.Size(60, 42)
        Me.F2.TabIndex = 2
        Me.F2.Text = "F2"
        Me.F2.UseVisualStyleBackColor = True
        '
        'F4
        '
        Me.F4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F4.Location = New System.Drawing.Point(320, 20)
        Me.F4.Margin = New System.Windows.Forms.Padding(4)
        Me.F4.Name = "F4"
        Me.F4.Size = New System.Drawing.Size(60, 42)
        Me.F4.TabIndex = 4
        Me.F4.Text = "F4"
        Me.F4.UseVisualStyleBackColor = True
        '
        'F3
        '
        Me.F3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F3.Location = New System.Drawing.Point(252, 20)
        Me.F3.Margin = New System.Windows.Forms.Padding(4)
        Me.F3.Name = "F3"
        Me.F3.Size = New System.Drawing.Size(60, 42)
        Me.F3.TabIndex = 3
        Me.F3.Text = "F3"
        Me.F3.UseVisualStyleBackColor = True
        '
        'F8
        '
        Me.F8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F8.Location = New System.Drawing.Point(612, 20)
        Me.F8.Margin = New System.Windows.Forms.Padding(4)
        Me.F8.Name = "F8"
        Me.F8.Size = New System.Drawing.Size(60, 42)
        Me.F8.TabIndex = 8
        Me.F8.Text = "F8"
        Me.F8.UseVisualStyleBackColor = True
        '
        'F7
        '
        Me.F7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F7.Location = New System.Drawing.Point(544, 20)
        Me.F7.Margin = New System.Windows.Forms.Padding(4)
        Me.F7.Name = "F7"
        Me.F7.Size = New System.Drawing.Size(60, 42)
        Me.F7.TabIndex = 7
        Me.F7.Text = "F7"
        Me.F7.UseVisualStyleBackColor = True
        '
        'F6
        '
        Me.F6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F6.Location = New System.Drawing.Point(476, 20)
        Me.F6.Margin = New System.Windows.Forms.Padding(4)
        Me.F6.Name = "F6"
        Me.F6.Size = New System.Drawing.Size(60, 42)
        Me.F6.TabIndex = 6
        Me.F6.Text = "F6"
        Me.F6.UseVisualStyleBackColor = True
        '
        'F5
        '
        Me.F5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F5.Location = New System.Drawing.Point(408, 20)
        Me.F5.Margin = New System.Windows.Forms.Padding(4)
        Me.F5.Name = "F5"
        Me.F5.Size = New System.Drawing.Size(60, 42)
        Me.F5.TabIndex = 5
        Me.F5.Text = "F5"
        Me.F5.UseVisualStyleBackColor = True
        '
        'F12
        '
        Me.F12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F12.Location = New System.Drawing.Point(894, 20)
        Me.F12.Margin = New System.Windows.Forms.Padding(4)
        Me.F12.Name = "F12"
        Me.F12.Size = New System.Drawing.Size(60, 42)
        Me.F12.TabIndex = 12
        Me.F12.Text = "F12"
        Me.F12.UseVisualStyleBackColor = True
        '
        'F11
        '
        Me.F11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F11.Location = New System.Drawing.Point(826, 20)
        Me.F11.Margin = New System.Windows.Forms.Padding(4)
        Me.F11.Name = "F11"
        Me.F11.Size = New System.Drawing.Size(60, 42)
        Me.F11.TabIndex = 11
        Me.F11.Text = "F11"
        Me.F11.UseVisualStyleBackColor = True
        '
        'F10
        '
        Me.F10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F10.Location = New System.Drawing.Point(758, 20)
        Me.F10.Margin = New System.Windows.Forms.Padding(4)
        Me.F10.Name = "F10"
        Me.F10.Size = New System.Drawing.Size(60, 42)
        Me.F10.TabIndex = 10
        Me.F10.Text = "F10"
        Me.F10.UseVisualStyleBackColor = True
        '
        'F9
        '
        Me.F9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F9.Location = New System.Drawing.Point(690, 20)
        Me.F9.Margin = New System.Windows.Forms.Padding(4)
        Me.F9.Name = "F9"
        Me.F9.Size = New System.Drawing.Size(60, 42)
        Me.F9.TabIndex = 9
        Me.F9.Text = "F9"
        Me.F9.UseVisualStyleBackColor = True
        '
        'Pause
        '
        Me.Pause.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Pause.Location = New System.Drawing.Point(1101, 20)
        Me.Pause.Margin = New System.Windows.Forms.Padding(4)
        Me.Pause.Name = "Pause"
        Me.Pause.Size = New System.Drawing.Size(60, 42)
        Me.Pause.TabIndex = 15
        Me.Pause.Text = "Pause" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attn"
        Me.Pause.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Pause.UseVisualStyleBackColor = True
        '
        'Scroll
        '
        Me.Scroll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Scroll.Location = New System.Drawing.Point(1033, 20)
        Me.Scroll.Margin = New System.Windows.Forms.Padding(4)
        Me.Scroll.Name = "Scroll"
        Me.Scroll.Size = New System.Drawing.Size(60, 42)
        Me.Scroll.TabIndex = 14
        Me.Scroll.Text = "Arrêt" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "défil"
        Me.Scroll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Scroll.UseVisualStyleBackColor = True
        '
        'PrintScreen
        '
        Me.PrintScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PrintScreen.Location = New System.Drawing.Point(965, 20)
        Me.PrintScreen.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintScreen.Name = "PrintScreen"
        Me.PrintScreen.Size = New System.Drawing.Size(60, 42)
        Me.PrintScreen.TabIndex = 13
        Me.PrintScreen.Text = "Impr" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "écran"
        Me.PrintScreen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.PrintScreen.UseVisualStyleBackColor = True
        '
        'Oem7
        '
        Me.Oem7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oem7.Location = New System.Drawing.Point(13, 74)
        Me.Oem7.Margin = New System.Windows.Forms.Padding(4)
        Me.Oem7.Name = "Oem7"
        Me.Oem7.Size = New System.Drawing.Size(60, 42)
        Me.Oem7.TabIndex = 16
        Me.Oem7.Text = "²"
        Me.Oem7.UseVisualStyleBackColor = True
        '
        'D1
        '
        Me.D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D1.Location = New System.Drawing.Point(81, 74)
        Me.D1.Margin = New System.Windows.Forms.Padding(4)
        Me.D1.Name = "D1"
        Me.D1.Size = New System.Drawing.Size(60, 42)
        Me.D1.TabIndex = 18
        Me.D1.Text = "1"
        Me.D1.UseVisualStyleBackColor = True
        '
        'D2
        '
        Me.D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D2.Location = New System.Drawing.Point(149, 74)
        Me.D2.Margin = New System.Windows.Forms.Padding(4)
        Me.D2.Name = "D2"
        Me.D2.Size = New System.Drawing.Size(60, 42)
        Me.D2.TabIndex = 19
        Me.D2.Text = "2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "é ~"
        Me.D2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D2.UseVisualStyleBackColor = True
        '
        'D3
        '
        Me.D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D3.Location = New System.Drawing.Point(217, 74)
        Me.D3.Margin = New System.Windows.Forms.Padding(4)
        Me.D3.Name = "D3"
        Me.D3.Size = New System.Drawing.Size(60, 42)
        Me.D3.TabIndex = 20
        Me.D3.Text = "3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & """ #"
        Me.D3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D3.UseVisualStyleBackColor = True
        '
        'D4
        '
        Me.D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D4.Location = New System.Drawing.Point(285, 74)
        Me.D4.Margin = New System.Windows.Forms.Padding(4)
        Me.D4.Name = "D4"
        Me.D4.Size = New System.Drawing.Size(60, 42)
        Me.D4.TabIndex = 21
        Me.D4.Text = "4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "' {"
        Me.D4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D4.UseVisualStyleBackColor = True
        '
        'D5
        '
        Me.D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D5.Location = New System.Drawing.Point(353, 74)
        Me.D5.Margin = New System.Windows.Forms.Padding(4)
        Me.D5.Name = "D5"
        Me.D5.Size = New System.Drawing.Size(60, 42)
        Me.D5.TabIndex = 22
        Me.D5.Text = "5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "( ["
        Me.D5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D5.UseVisualStyleBackColor = True
        '
        'D6
        '
        Me.D6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D6.Location = New System.Drawing.Point(421, 74)
        Me.D6.Margin = New System.Windows.Forms.Padding(4)
        Me.D6.Name = "D6"
        Me.D6.Size = New System.Drawing.Size(60, 42)
        Me.D6.TabIndex = 23
        Me.D6.Text = "6" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "- |"
        Me.D6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D6.UseVisualStyleBackColor = True
        '
        'D7
        '
        Me.D7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D7.Location = New System.Drawing.Point(489, 74)
        Me.D7.Margin = New System.Windows.Forms.Padding(4)
        Me.D7.Name = "D7"
        Me.D7.Size = New System.Drawing.Size(60, 42)
        Me.D7.TabIndex = 24
        Me.D7.Text = "7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "è `"
        Me.D7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D7.UseVisualStyleBackColor = True
        '
        'D8
        '
        Me.D8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D8.Location = New System.Drawing.Point(557, 74)
        Me.D8.Margin = New System.Windows.Forms.Padding(4)
        Me.D8.Name = "D8"
        Me.D8.Size = New System.Drawing.Size(60, 42)
        Me.D8.TabIndex = 25
        Me.D8.Text = "8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "_ \"
        Me.D8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D8.UseVisualStyleBackColor = True
        '
        'D9
        '
        Me.D9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D9.Location = New System.Drawing.Point(625, 74)
        Me.D9.Margin = New System.Windows.Forms.Padding(4)
        Me.D9.Name = "D9"
        Me.D9.Size = New System.Drawing.Size(60, 42)
        Me.D9.TabIndex = 26
        Me.D9.Text = "9" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ç ^"
        Me.D9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D9.UseVisualStyleBackColor = True
        '
        'D0
        '
        Me.D0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D0.Location = New System.Drawing.Point(693, 74)
        Me.D0.Margin = New System.Windows.Forms.Padding(4)
        Me.D0.Name = "D0"
        Me.D0.Size = New System.Drawing.Size(60, 42)
        Me.D0.TabIndex = 27
        Me.D0.Text = "0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "à @"
        Me.D0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.D0.UseVisualStyleBackColor = True
        '
        'OemOpenBrackets
        '
        Me.OemOpenBrackets.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OemOpenBrackets.Location = New System.Drawing.Point(761, 74)
        Me.OemOpenBrackets.Margin = New System.Windows.Forms.Padding(4)
        Me.OemOpenBrackets.Name = "OemOpenBrackets"
        Me.OemOpenBrackets.Size = New System.Drawing.Size(60, 42)
        Me.OemOpenBrackets.TabIndex = 28
        Me.OemOpenBrackets.Text = "°" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ") ]"
        Me.OemOpenBrackets.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OemOpenBrackets.UseVisualStyleBackColor = True
        '
        'Oemplus
        '
        Me.Oemplus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oemplus.Location = New System.Drawing.Point(829, 74)
        Me.Oemplus.Margin = New System.Windows.Forms.Padding(4)
        Me.Oemplus.Name = "Oemplus"
        Me.Oemplus.Size = New System.Drawing.Size(60, 42)
        Me.Oemplus.TabIndex = 29
        Me.Oemplus.Text = "+" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "= }"
        Me.Oemplus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oemplus.UseVisualStyleBackColor = True
        '
        'Back
        '
        Me.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Back.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Back.Location = New System.Drawing.Point(897, 74)
        Me.Back.Margin = New System.Windows.Forms.Padding(4)
        Me.Back.Name = "Back"
        Me.Back.Size = New System.Drawing.Size(57, 42)
        Me.Back.TabIndex = 30
        Me.Back.Text = "⇽"
        Me.Back.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Back.UseVisualStyleBackColor = True
        '
        'Insert
        '
        Me.Insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Insert.Location = New System.Drawing.Point(965, 74)
        Me.Insert.Margin = New System.Windows.Forms.Padding(4)
        Me.Insert.Name = "Insert"
        Me.Insert.Size = New System.Drawing.Size(60, 42)
        Me.Insert.TabIndex = 31
        Me.Insert.Text = "Ins"
        Me.Insert.UseVisualStyleBackColor = True
        '
        'Delete
        '
        Me.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Delete.Location = New System.Drawing.Point(965, 124)
        Me.Delete.Margin = New System.Windows.Forms.Padding(4)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(60, 42)
        Me.Delete.TabIndex = 32
        Me.Delete.Text = "Suppr"
        Me.Delete.UseVisualStyleBackColor = True
        '
        'Endd
        '
        Me.Endd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Endd.Location = New System.Drawing.Point(1033, 124)
        Me.Endd.Margin = New System.Windows.Forms.Padding(4)
        Me.Endd.Name = "Endd"
        Me.Endd.Size = New System.Drawing.Size(60, 42)
        Me.Endd.TabIndex = 34
        Me.Endd.Text = "Fin"
        Me.Endd.UseVisualStyleBackColor = True
        '
        'Home
        '
        Me.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Home.Location = New System.Drawing.Point(1033, 74)
        Me.Home.Margin = New System.Windows.Forms.Padding(4)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(60, 42)
        Me.Home.TabIndex = 33
        Me.Home.Text = "^" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "|"
        Me.Home.UseVisualStyleBackColor = True
        '
        'PageUp
        '
        Me.PageUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PageUp.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PageUp.Location = New System.Drawing.Point(1101, 74)
        Me.PageUp.Margin = New System.Windows.Forms.Padding(4)
        Me.PageUp.Name = "PageUp"
        Me.PageUp.Size = New System.Drawing.Size(60, 42)
        Me.PageUp.TabIndex = 35
        Me.PageUp.Text = "⇑"
        Me.PageUp.UseVisualStyleBackColor = True
        '
        'Nextt
        '
        Me.Nextt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Nextt.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nextt.Location = New System.Drawing.Point(1101, 124)
        Me.Nextt.Margin = New System.Windows.Forms.Padding(4)
        Me.Nextt.Name = "Nextt"
        Me.Nextt.Size = New System.Drawing.Size(60, 42)
        Me.Nextt.TabIndex = 36
        Me.Nextt.Text = "⇓"
        Me.Nextt.UseVisualStyleBackColor = True
        '
        'ReturnBig
        '
        Me.ReturnBig.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ReturnBig.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnBig.Location = New System.Drawing.Point(897, 121)
        Me.ReturnBig.Margin = New System.Windows.Forms.Padding(4)
        Me.ReturnBig.Name = "ReturnBig"
        Me.ReturnBig.Size = New System.Drawing.Size(57, 92)
        Me.ReturnBig.TabIndex = 37
        Me.ReturnBig.Text = "⇽"
        Me.ReturnBig.UseVisualStyleBackColor = True
        '
        'RShiftKey
        '
        Me.RShiftKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RShiftKey.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RShiftKey.Location = New System.Drawing.Point(826, 221)
        Me.RShiftKey.Margin = New System.Windows.Forms.Padding(4)
        Me.RShiftKey.Name = "RShiftKey"
        Me.RShiftKey.Size = New System.Drawing.Size(128, 42)
        Me.RShiftKey.TabIndex = 38
        Me.RShiftKey.Text = "↟"
        Me.RShiftKey.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RShiftKey.UseVisualStyleBackColor = True
        '
        'Oem1
        '
        Me.Oem1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oem1.Location = New System.Drawing.Point(829, 121)
        Me.Oem1.Margin = New System.Windows.Forms.Padding(4)
        Me.Oem1.Name = "Oem1"
        Me.Oem1.Size = New System.Drawing.Size(60, 42)
        Me.Oem1.TabIndex = 39
        Me.Oem1.Text = "£" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$ ¤"
        Me.Oem1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oem1.UseVisualStyleBackColor = True
        '
        'Oem5
        '
        Me.Oem5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oem5.Location = New System.Drawing.Point(829, 171)
        Me.Oem5.Margin = New System.Windows.Forms.Padding(4)
        Me.Oem5.Name = "Oem5"
        Me.Oem5.Size = New System.Drawing.Size(60, 42)
        Me.Oem5.TabIndex = 40
        Me.Oem5.Text = "µ" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " *"
        Me.Oem5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oem5.UseVisualStyleBackColor = True
        '
        'Oem6
        '
        Me.Oem6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oem6.Location = New System.Drawing.Point(761, 121)
        Me.Oem6.Margin = New System.Windows.Forms.Padding(4)
        Me.Oem6.Name = "Oem6"
        Me.Oem6.Size = New System.Drawing.Size(60, 42)
        Me.Oem6.TabIndex = 41
        Me.Oem6.Text = "¨" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " ^"
        Me.Oem6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oem6.UseVisualStyleBackColor = True
        '
        'P
        '
        Me.P.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.P.Location = New System.Drawing.Point(693, 121)
        Me.P.Margin = New System.Windows.Forms.Padding(4)
        Me.P.Name = "P"
        Me.P.Size = New System.Drawing.Size(60, 42)
        Me.P.TabIndex = 42
        Me.P.Text = "P"
        Me.P.UseVisualStyleBackColor = True
        '
        'O
        '
        Me.O.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.O.Location = New System.Drawing.Point(625, 121)
        Me.O.Margin = New System.Windows.Forms.Padding(4)
        Me.O.Name = "O"
        Me.O.Size = New System.Drawing.Size(60, 42)
        Me.O.TabIndex = 43
        Me.O.Text = "O"
        Me.O.UseVisualStyleBackColor = True
        '
        'I
        '
        Me.I.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.I.Location = New System.Drawing.Point(557, 121)
        Me.I.Margin = New System.Windows.Forms.Padding(4)
        Me.I.Name = "I"
        Me.I.Size = New System.Drawing.Size(60, 42)
        Me.I.TabIndex = 44
        Me.I.Text = "I"
        Me.I.UseVisualStyleBackColor = True
        '
        'U
        '
        Me.U.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.U.Location = New System.Drawing.Point(489, 121)
        Me.U.Margin = New System.Windows.Forms.Padding(4)
        Me.U.Name = "U"
        Me.U.Size = New System.Drawing.Size(60, 42)
        Me.U.TabIndex = 45
        Me.U.Text = "U"
        Me.U.UseVisualStyleBackColor = True
        '
        'Y
        '
        Me.Y.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Y.Location = New System.Drawing.Point(421, 121)
        Me.Y.Margin = New System.Windows.Forms.Padding(4)
        Me.Y.Name = "Y"
        Me.Y.Size = New System.Drawing.Size(60, 42)
        Me.Y.TabIndex = 46
        Me.Y.Text = "Y"
        Me.Y.UseVisualStyleBackColor = True
        '
        'T
        '
        Me.T.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.T.Location = New System.Drawing.Point(353, 121)
        Me.T.Margin = New System.Windows.Forms.Padding(4)
        Me.T.Name = "T"
        Me.T.Size = New System.Drawing.Size(60, 42)
        Me.T.TabIndex = 47
        Me.T.Text = "T"
        Me.T.UseVisualStyleBackColor = True
        '
        'R
        '
        Me.R.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.R.Location = New System.Drawing.Point(285, 121)
        Me.R.Margin = New System.Windows.Forms.Padding(4)
        Me.R.Name = "R"
        Me.R.Size = New System.Drawing.Size(60, 42)
        Me.R.TabIndex = 48
        Me.R.Text = "R"
        Me.R.UseVisualStyleBackColor = True
        '
        'E
        '
        Me.E.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.E.Location = New System.Drawing.Point(217, 121)
        Me.E.Margin = New System.Windows.Forms.Padding(4)
        Me.E.Name = "E"
        Me.E.Size = New System.Drawing.Size(60, 42)
        Me.E.TabIndex = 49
        Me.E.Text = "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " €"
        Me.E.UseVisualStyleBackColor = True
        '
        'Z
        '
        Me.Z.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Z.Location = New System.Drawing.Point(149, 121)
        Me.Z.Margin = New System.Windows.Forms.Padding(4)
        Me.Z.Name = "Z"
        Me.Z.Size = New System.Drawing.Size(60, 42)
        Me.Z.TabIndex = 50
        Me.Z.Text = "Z"
        Me.Z.UseVisualStyleBackColor = True
        '
        'A
        '
        Me.A.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.A.Location = New System.Drawing.Point(81, 121)
        Me.A.Margin = New System.Windows.Forms.Padding(4)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(60, 42)
        Me.A.TabIndex = 51
        Me.A.Text = "A"
        Me.A.UseVisualStyleBackColor = True
        '
        'Tab
        '
        Me.Tab.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Tab.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tab.Location = New System.Drawing.Point(13, 121)
        Me.Tab.Margin = New System.Windows.Forms.Padding(4)
        Me.Tab.Name = "Tab"
        Me.Tab.Size = New System.Drawing.Size(60, 42)
        Me.Tab.TabIndex = 52
        Me.Tab.Text = "⇆"
        Me.Tab.UseVisualStyleBackColor = True
        '
        'M
        '
        Me.M.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.M.Location = New System.Drawing.Point(693, 171)
        Me.M.Margin = New System.Windows.Forms.Padding(4)
        Me.M.Name = "M"
        Me.M.Size = New System.Drawing.Size(60, 42)
        Me.M.TabIndex = 53
        Me.M.Text = "M"
        Me.M.UseVisualStyleBackColor = True
        '
        'Oemtilde
        '
        Me.Oemtilde.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oemtilde.Location = New System.Drawing.Point(761, 171)
        Me.Oemtilde.Margin = New System.Windows.Forms.Padding(4)
        Me.Oemtilde.Name = "Oemtilde"
        Me.Oemtilde.Size = New System.Drawing.Size(60, 42)
        Me.Oemtilde.TabIndex = 54
        Me.Oemtilde.Text = "%" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " ù"
        Me.Oemtilde.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oemtilde.UseVisualStyleBackColor = True
        '
        'L
        '
        Me.L.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L.Location = New System.Drawing.Point(625, 171)
        Me.L.Margin = New System.Windows.Forms.Padding(4)
        Me.L.Name = "L"
        Me.L.Size = New System.Drawing.Size(60, 42)
        Me.L.TabIndex = 55
        Me.L.Text = "L"
        Me.L.UseVisualStyleBackColor = True
        '
        'K
        '
        Me.K.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.K.Location = New System.Drawing.Point(557, 171)
        Me.K.Margin = New System.Windows.Forms.Padding(4)
        Me.K.Name = "K"
        Me.K.Size = New System.Drawing.Size(60, 42)
        Me.K.TabIndex = 56
        Me.K.Text = "K"
        Me.K.UseVisualStyleBackColor = True
        '
        'J
        '
        Me.J.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.J.Location = New System.Drawing.Point(489, 171)
        Me.J.Margin = New System.Windows.Forms.Padding(4)
        Me.J.Name = "J"
        Me.J.Size = New System.Drawing.Size(60, 42)
        Me.J.TabIndex = 57
        Me.J.Text = "J"
        Me.J.UseVisualStyleBackColor = True
        '
        'H
        '
        Me.H.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.H.Location = New System.Drawing.Point(421, 171)
        Me.H.Margin = New System.Windows.Forms.Padding(4)
        Me.H.Name = "H"
        Me.H.Size = New System.Drawing.Size(60, 42)
        Me.H.TabIndex = 58
        Me.H.Text = "H"
        Me.H.UseVisualStyleBackColor = True
        '
        'G
        '
        Me.G.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.G.Location = New System.Drawing.Point(353, 171)
        Me.G.Margin = New System.Windows.Forms.Padding(4)
        Me.G.Name = "G"
        Me.G.Size = New System.Drawing.Size(60, 42)
        Me.G.TabIndex = 59
        Me.G.Text = "G"
        Me.G.UseVisualStyleBackColor = True
        '
        'F
        '
        Me.F.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F.Location = New System.Drawing.Point(285, 171)
        Me.F.Margin = New System.Windows.Forms.Padding(4)
        Me.F.Name = "F"
        Me.F.Size = New System.Drawing.Size(60, 42)
        Me.F.TabIndex = 60
        Me.F.Text = "F"
        Me.F.UseVisualStyleBackColor = True
        '
        'D
        '
        Me.D.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D.Location = New System.Drawing.Point(217, 171)
        Me.D.Margin = New System.Windows.Forms.Padding(4)
        Me.D.Name = "D"
        Me.D.Size = New System.Drawing.Size(60, 42)
        Me.D.TabIndex = 61
        Me.D.Text = "D"
        Me.D.UseVisualStyleBackColor = True
        '
        'S
        '
        Me.S.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.S.Location = New System.Drawing.Point(149, 171)
        Me.S.Margin = New System.Windows.Forms.Padding(4)
        Me.S.Name = "S"
        Me.S.Size = New System.Drawing.Size(60, 42)
        Me.S.TabIndex = 62
        Me.S.Text = "S"
        Me.S.UseVisualStyleBackColor = True
        '
        'Q
        '
        Me.Q.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Q.Location = New System.Drawing.Point(81, 171)
        Me.Q.Margin = New System.Windows.Forms.Padding(4)
        Me.Q.Name = "Q"
        Me.Q.Size = New System.Drawing.Size(60, 42)
        Me.Q.TabIndex = 63
        Me.Q.Text = "Q"
        Me.Q.UseVisualStyleBackColor = True
        '
        'Capital
        '
        Me.Capital.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Capital.Location = New System.Drawing.Point(13, 171)
        Me.Capital.Margin = New System.Windows.Forms.Padding(4)
        Me.Capital.Name = "Capital"
        Me.Capital.Size = New System.Drawing.Size(60, 42)
        Me.Capital.TabIndex = 64
        Me.Capital.Text = "🔐"
        Me.Capital.UseVisualStyleBackColor = True
        '
        'Oem8
        '
        Me.Oem8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oem8.Location = New System.Drawing.Point(761, 221)
        Me.Oem8.Margin = New System.Windows.Forms.Padding(4)
        Me.Oem8.Name = "Oem8"
        Me.Oem8.Size = New System.Drawing.Size(60, 42)
        Me.Oem8.TabIndex = 65
        Me.Oem8.Text = "§" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " !"
        Me.Oem8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oem8.UseVisualStyleBackColor = True
        '
        'OemQuestion
        '
        Me.OemQuestion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OemQuestion.Location = New System.Drawing.Point(693, 221)
        Me.OemQuestion.Margin = New System.Windows.Forms.Padding(4)
        Me.OemQuestion.Name = "OemQuestion"
        Me.OemQuestion.Size = New System.Drawing.Size(60, 42)
        Me.OemQuestion.TabIndex = 66
        Me.OemQuestion.Text = "/" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " :"
        Me.OemQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OemQuestion.UseVisualStyleBackColor = True
        '
        'OemPeriod
        '
        Me.OemPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OemPeriod.Location = New System.Drawing.Point(625, 221)
        Me.OemPeriod.Margin = New System.Windows.Forms.Padding(4)
        Me.OemPeriod.Name = "OemPeriod"
        Me.OemPeriod.Size = New System.Drawing.Size(60, 42)
        Me.OemPeriod.TabIndex = 67
        Me.OemPeriod.Text = "." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " ;"
        Me.OemPeriod.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OemPeriod.UseVisualStyleBackColor = True
        '
        'Oemcomma
        '
        Me.Oemcomma.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Oemcomma.Location = New System.Drawing.Point(557, 221)
        Me.Oemcomma.Margin = New System.Windows.Forms.Padding(4)
        Me.Oemcomma.Name = "Oemcomma"
        Me.Oemcomma.Size = New System.Drawing.Size(60, 42)
        Me.Oemcomma.TabIndex = 68
        Me.Oemcomma.Text = "?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " ,"
        Me.Oemcomma.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Oemcomma.UseVisualStyleBackColor = True
        '
        'N
        '
        Me.N.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N.Location = New System.Drawing.Point(489, 221)
        Me.N.Margin = New System.Windows.Forms.Padding(4)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(60, 42)
        Me.N.TabIndex = 69
        Me.N.Text = "N"
        Me.N.UseVisualStyleBackColor = True
        '
        'B
        '
        Me.B.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B.Location = New System.Drawing.Point(421, 221)
        Me.B.Margin = New System.Windows.Forms.Padding(4)
        Me.B.Name = "B"
        Me.B.Size = New System.Drawing.Size(60, 42)
        Me.B.TabIndex = 70
        Me.B.Text = "B"
        Me.B.UseVisualStyleBackColor = True
        '
        'V
        '
        Me.V.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.V.Location = New System.Drawing.Point(353, 221)
        Me.V.Margin = New System.Windows.Forms.Padding(4)
        Me.V.Name = "V"
        Me.V.Size = New System.Drawing.Size(60, 42)
        Me.V.TabIndex = 71
        Me.V.Text = "V"
        Me.V.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C.Location = New System.Drawing.Point(285, 221)
        Me.C.Margin = New System.Windows.Forms.Padding(4)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(60, 42)
        Me.C.TabIndex = 72
        Me.C.Text = "C"
        Me.C.UseVisualStyleBackColor = True
        '
        'X
        '
        Me.X.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.X.Location = New System.Drawing.Point(217, 221)
        Me.X.Margin = New System.Windows.Forms.Padding(4)
        Me.X.Name = "X"
        Me.X.Size = New System.Drawing.Size(60, 42)
        Me.X.TabIndex = 73
        Me.X.Text = "X"
        Me.X.UseVisualStyleBackColor = True
        '
        'W
        '
        Me.W.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.W.Location = New System.Drawing.Point(149, 221)
        Me.W.Margin = New System.Windows.Forms.Padding(4)
        Me.W.Name = "W"
        Me.W.Size = New System.Drawing.Size(60, 42)
        Me.W.TabIndex = 74
        Me.W.Text = "W"
        Me.W.UseVisualStyleBackColor = True
        '
        'OemBackslash
        '
        Me.OemBackslash.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OemBackslash.Location = New System.Drawing.Point(81, 221)
        Me.OemBackslash.Margin = New System.Windows.Forms.Padding(4)
        Me.OemBackslash.Name = "OemBackslash"
        Me.OemBackslash.Size = New System.Drawing.Size(60, 42)
        Me.OemBackslash.TabIndex = 75
        Me.OemBackslash.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " <"
        Me.OemBackslash.UseVisualStyleBackColor = True
        '
        'LShiftKey
        '
        Me.LShiftKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LShiftKey.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LShiftKey.Location = New System.Drawing.Point(13, 221)
        Me.LShiftKey.Margin = New System.Windows.Forms.Padding(4)
        Me.LShiftKey.Name = "LShiftKey"
        Me.LShiftKey.Size = New System.Drawing.Size(60, 42)
        Me.LShiftKey.TabIndex = 76
        Me.LShiftKey.Text = "↟"
        Me.LShiftKey.UseVisualStyleBackColor = True
        '
        'LControlKey
        '
        Me.LControlKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LControlKey.Location = New System.Drawing.Point(13, 271)
        Me.LControlKey.Margin = New System.Windows.Forms.Padding(4)
        Me.LControlKey.Name = "LControlKey"
        Me.LControlKey.Size = New System.Drawing.Size(60, 42)
        Me.LControlKey.TabIndex = 77
        Me.LControlKey.Text = "Ctrl"
        Me.LControlKey.UseVisualStyleBackColor = True
        '
        'Up
        '
        Me.Up.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Up.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Up.Location = New System.Drawing.Point(1033, 221)
        Me.Up.Margin = New System.Windows.Forms.Padding(4)
        Me.Up.Name = "Up"
        Me.Up.Size = New System.Drawing.Size(60, 42)
        Me.Up.TabIndex = 78
        Me.Up.Text = "🠕"
        Me.Up.UseVisualStyleBackColor = True
        '
        'Left
        '
        Me.Left.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Left.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Left.Location = New System.Drawing.Point(965, 271)
        Me.Left.Margin = New System.Windows.Forms.Padding(4)
        Me.Left.Name = "Left"
        Me.Left.Size = New System.Drawing.Size(60, 42)
        Me.Left.TabIndex = 79
        Me.Left.Text = "🠔"
        Me.Left.UseVisualStyleBackColor = True
        '
        'Down
        '
        Me.Down.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Down.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Down.Location = New System.Drawing.Point(1033, 271)
        Me.Down.Margin = New System.Windows.Forms.Padding(4)
        Me.Down.Name = "Down"
        Me.Down.Size = New System.Drawing.Size(60, 42)
        Me.Down.TabIndex = 80
        Me.Down.Text = "🠗"
        Me.Down.UseVisualStyleBackColor = True
        '
        'Right
        '
        Me.Right.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Right.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Right.Location = New System.Drawing.Point(1101, 271)
        Me.Right.Margin = New System.Windows.Forms.Padding(4)
        Me.Right.Name = "Right"
        Me.Right.Size = New System.Drawing.Size(60, 42)
        Me.Right.TabIndex = 81
        Me.Right.Text = "🠖"
        Me.Right.UseVisualStyleBackColor = True
        '
        'RControlKey
        '
        Me.RControlKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RControlKey.Location = New System.Drawing.Point(894, 271)
        Me.RControlKey.Margin = New System.Windows.Forms.Padding(4)
        Me.RControlKey.Name = "RControlKey"
        Me.RControlKey.Size = New System.Drawing.Size(60, 42)
        Me.RControlKey.TabIndex = 82
        Me.RControlKey.Text = "Ctrl"
        Me.RControlKey.UseVisualStyleBackColor = True
        '
        'Apps
        '
        Me.Apps.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Apps.Location = New System.Drawing.Point(829, 271)
        Me.Apps.Margin = New System.Windows.Forms.Padding(4)
        Me.Apps.Name = "Apps"
        Me.Apps.Size = New System.Drawing.Size(60, 42)
        Me.Apps.TabIndex = 83
        Me.Apps.Text = "?"
        Me.Apps.UseVisualStyleBackColor = True
        '
        'RWin
        '
        Me.RWin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RWin.Location = New System.Drawing.Point(761, 271)
        Me.RWin.Margin = New System.Windows.Forms.Padding(4)
        Me.RWin.Name = "RWin"
        Me.RWin.Size = New System.Drawing.Size(60, 42)
        Me.RWin.TabIndex = 84
        Me.RWin.Text = "█ █" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "█ █"
        Me.RWin.UseVisualStyleBackColor = True
        '
        'RMenu
        '
        Me.RMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RMenu.Location = New System.Drawing.Point(693, 271)
        Me.RMenu.Margin = New System.Windows.Forms.Padding(4)
        Me.RMenu.Name = "RMenu"
        Me.RMenu.Size = New System.Drawing.Size(60, 42)
        Me.RMenu.TabIndex = 85
        Me.RMenu.Text = "AltGr"
        Me.RMenu.UseVisualStyleBackColor = True
        '
        'LMenu
        '
        Me.LMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LMenu.Location = New System.Drawing.Point(149, 271)
        Me.LMenu.Margin = New System.Windows.Forms.Padding(4)
        Me.LMenu.Name = "LMenu"
        Me.LMenu.Size = New System.Drawing.Size(60, 42)
        Me.LMenu.TabIndex = 86
        Me.LMenu.Text = "Alt"
        Me.LMenu.UseVisualStyleBackColor = True
        '
        'LWin
        '
        Me.LWin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LWin.Location = New System.Drawing.Point(81, 271)
        Me.LWin.Margin = New System.Windows.Forms.Padding(4)
        Me.LWin.Name = "LWin"
        Me.LWin.Size = New System.Drawing.Size(60, 42)
        Me.LWin.TabIndex = 87
        Me.LWin.Text = "█ █" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "█ █"
        Me.LWin.UseVisualStyleBackColor = True
        '
        'Space
        '
        Me.Space.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Space.Location = New System.Drawing.Point(217, 271)
        Me.Space.Margin = New System.Windows.Forms.Padding(4)
        Me.Space.Name = "Space"
        Me.Space.Size = New System.Drawing.Size(468, 42)
        Me.Space.TabIndex = 88
        Me.Space.Text = "SPACE"
        Me.Space.UseVisualStyleBackColor = True
        '
        'NumLock
        '
        Me.NumLock.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumLock.Location = New System.Drawing.Point(1169, 74)
        Me.NumLock.Margin = New System.Windows.Forms.Padding(4)
        Me.NumLock.Name = "NumLock"
        Me.NumLock.Size = New System.Drawing.Size(60, 42)
        Me.NumLock.TabIndex = 89
        Me.NumLock.Text = "Verr" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Num"
        Me.NumLock.UseVisualStyleBackColor = True
        '
        'Divide
        '
        Me.Divide.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Divide.Location = New System.Drawing.Point(1237, 74)
        Me.Divide.Margin = New System.Windows.Forms.Padding(4)
        Me.Divide.Name = "Divide"
        Me.Divide.Size = New System.Drawing.Size(60, 42)
        Me.Divide.TabIndex = 90
        Me.Divide.Text = "/"
        Me.Divide.UseVisualStyleBackColor = True
        '
        'Multiply
        '
        Me.Multiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Multiply.Location = New System.Drawing.Point(1305, 74)
        Me.Multiply.Margin = New System.Windows.Forms.Padding(4)
        Me.Multiply.Name = "Multiply"
        Me.Multiply.Size = New System.Drawing.Size(60, 42)
        Me.Multiply.TabIndex = 91
        Me.Multiply.Text = "*"
        Me.Multiply.UseVisualStyleBackColor = True
        '
        'Subtract
        '
        Me.Subtract.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Subtract.Location = New System.Drawing.Point(1374, 74)
        Me.Subtract.Margin = New System.Windows.Forms.Padding(4)
        Me.Subtract.Name = "Subtract"
        Me.Subtract.Size = New System.Drawing.Size(60, 42)
        Me.Subtract.TabIndex = 92
        Me.Subtract.Text = "-"
        Me.Subtract.UseVisualStyleBackColor = True
        '
        'NumPad7
        '
        Me.NumPad7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad7.Location = New System.Drawing.Point(1169, 124)
        Me.NumPad7.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad7.Name = "NumPad7"
        Me.NumPad7.Size = New System.Drawing.Size(60, 42)
        Me.NumPad7.TabIndex = 93
        Me.NumPad7.Text = "7"
        Me.NumPad7.UseVisualStyleBackColor = True
        '
        'NumPad8
        '
        Me.NumPad8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad8.Location = New System.Drawing.Point(1237, 124)
        Me.NumPad8.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad8.Name = "NumPad8"
        Me.NumPad8.Size = New System.Drawing.Size(60, 42)
        Me.NumPad8.TabIndex = 94
        Me.NumPad8.Text = "8"
        Me.NumPad8.UseVisualStyleBackColor = True
        '
        'NumPad9
        '
        Me.NumPad9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad9.Location = New System.Drawing.Point(1305, 124)
        Me.NumPad9.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad9.Name = "NumPad9"
        Me.NumPad9.Size = New System.Drawing.Size(60, 42)
        Me.NumPad9.TabIndex = 95
        Me.NumPad9.Text = "9"
        Me.NumPad9.UseVisualStyleBackColor = True
        '
        'Add
        '
        Me.Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Add.Location = New System.Drawing.Point(1373, 124)
        Me.Add.Margin = New System.Windows.Forms.Padding(4)
        Me.Add.Name = "Add"
        Me.Add.Size = New System.Drawing.Size(60, 91)
        Me.Add.TabIndex = 96
        Me.Add.Text = "+"
        Me.Add.UseVisualStyleBackColor = True
        '
        'NumPad6
        '
        Me.NumPad6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad6.Location = New System.Drawing.Point(1305, 173)
        Me.NumPad6.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad6.Name = "NumPad6"
        Me.NumPad6.Size = New System.Drawing.Size(60, 42)
        Me.NumPad6.TabIndex = 97
        Me.NumPad6.Text = "6"
        Me.NumPad6.UseVisualStyleBackColor = True
        '
        'NumPad3
        '
        Me.NumPad3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad3.Location = New System.Drawing.Point(1305, 223)
        Me.NumPad3.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad3.Name = "NumPad3"
        Me.NumPad3.Size = New System.Drawing.Size(60, 42)
        Me.NumPad3.TabIndex = 98
        Me.NumPad3.Text = "3"
        Me.NumPad3.UseVisualStyleBackColor = True
        '
        'Decimall
        '
        Me.Decimall.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Decimall.Location = New System.Drawing.Point(1305, 271)
        Me.Decimall.Margin = New System.Windows.Forms.Padding(4)
        Me.Decimall.Name = "Decimall"
        Me.Decimall.Size = New System.Drawing.Size(60, 42)
        Me.Decimall.TabIndex = 99
        Me.Decimall.Text = "." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Suppr"
        Me.Decimall.UseVisualStyleBackColor = True
        '
        'NumPad5
        '
        Me.NumPad5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad5.Location = New System.Drawing.Point(1237, 173)
        Me.NumPad5.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad5.Name = "NumPad5"
        Me.NumPad5.Size = New System.Drawing.Size(60, 42)
        Me.NumPad5.TabIndex = 100
        Me.NumPad5.Text = "5"
        Me.NumPad5.UseVisualStyleBackColor = True
        '
        'NumPad2
        '
        Me.NumPad2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad2.Location = New System.Drawing.Point(1237, 223)
        Me.NumPad2.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad2.Name = "NumPad2"
        Me.NumPad2.Size = New System.Drawing.Size(60, 42)
        Me.NumPad2.TabIndex = 101
        Me.NumPad2.Text = "2"
        Me.NumPad2.UseVisualStyleBackColor = True
        '
        'NumPad0
        '
        Me.NumPad0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad0.Location = New System.Drawing.Point(1169, 271)
        Me.NumPad0.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad0.Name = "NumPad0"
        Me.NumPad0.Size = New System.Drawing.Size(128, 42)
        Me.NumPad0.TabIndex = 102
        Me.NumPad0.Text = "0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Inser"
        Me.NumPad0.UseVisualStyleBackColor = True
        '
        'NumPad4
        '
        Me.NumPad4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad4.Location = New System.Drawing.Point(1169, 173)
        Me.NumPad4.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad4.Name = "NumPad4"
        Me.NumPad4.Size = New System.Drawing.Size(60, 42)
        Me.NumPad4.TabIndex = 103
        Me.NumPad4.Text = "4"
        Me.NumPad4.UseVisualStyleBackColor = True
        '
        'NumPad1
        '
        Me.NumPad1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NumPad1.Location = New System.Drawing.Point(1169, 223)
        Me.NumPad1.Margin = New System.Windows.Forms.Padding(4)
        Me.NumPad1.Name = "NumPad1"
        Me.NumPad1.Size = New System.Drawing.Size(60, 42)
        Me.NumPad1.TabIndex = 104
        Me.NumPad1.Text = "1"
        Me.NumPad1.UseVisualStyleBackColor = True
        '
        'Returnn
        '
        Me.Returnn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Returnn.Location = New System.Drawing.Point(1373, 224)
        Me.Returnn.Margin = New System.Windows.Forms.Padding(4)
        Me.Returnn.Name = "Returnn"
        Me.Returnn.Size = New System.Drawing.Size(60, 89)
        Me.Returnn.TabIndex = 105
        Me.Returnn.Text = "Enter"
        Me.Returnn.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(1182, 28)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(33, 26)
        Me.Button1.TabIndex = 106
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(1248, 28)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(33, 26)
        Me.Button2.TabIndex = 107
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Red
        Me.Button3.Location = New System.Drawing.Point(1674, 0)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(41, 33)
        Me.Button3.TabIndex = 108
        Me.Button3.Text = "X"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'LeftMouseButton
        '
        Me.LeftMouseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LeftMouseButton.Location = New System.Drawing.Point(1474, 97)
        Me.LeftMouseButton.Margin = New System.Windows.Forms.Padding(4)
        Me.LeftMouseButton.Name = "LeftMouseButton"
        Me.LeftMouseButton.Size = New System.Drawing.Size(86, 166)
        Me.LeftMouseButton.TabIndex = 109
        Me.LeftMouseButton.Text = "left Button"
        Me.LeftMouseButton.UseVisualStyleBackColor = True
        '
        'RightMouseButton
        '
        Me.RightMouseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RightMouseButton.Location = New System.Drawing.Point(1615, 97)
        Me.RightMouseButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RightMouseButton.Name = "RightMouseButton"
        Me.RightMouseButton.Size = New System.Drawing.Size(86, 166)
        Me.RightMouseButton.TabIndex = 110
        Me.RightMouseButton.Text = "Right Button"
        Me.RightMouseButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1547, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 18)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Mouse"
        '
        'WheelButtonUp
        '
        Me.WheelButtonUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.WheelButtonUp.Location = New System.Drawing.Point(1566, 97)
        Me.WheelButtonUp.Margin = New System.Windows.Forms.Padding(4)
        Me.WheelButtonUp.Name = "WheelButtonUp"
        Me.WheelButtonUp.Size = New System.Drawing.Size(41, 46)
        Me.WheelButtonUp.TabIndex = 112
        Me.WheelButtonUp.Text = "W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "UP"
        Me.WheelButtonUp.UseVisualStyleBackColor = True
        '
        'WheelButtonDown
        '
        Me.WheelButtonDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.WheelButtonDown.Location = New System.Drawing.Point(1566, 149)
        Me.WheelButtonDown.Margin = New System.Windows.Forms.Padding(4)
        Me.WheelButtonDown.Name = "WheelButtonDown"
        Me.WheelButtonDown.Size = New System.Drawing.Size(41, 46)
        Me.WheelButtonDown.TabIndex = 113
        Me.WheelButtonDown.Text = "W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "DW"
        Me.WheelButtonDown.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(1508, 3)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(159, 20)
        Me.CheckBox1.TabIndex = 114
        Me.CheckBox1.Text = "Show Mouse Viewer"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1716, 330)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.WheelButtonDown)
        Me.Controls.Add(Me.WheelButtonUp)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RightMouseButton)
        Me.Controls.Add(Me.LeftMouseButton)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Returnn)
        Me.Controls.Add(Me.NumPad1)
        Me.Controls.Add(Me.NumPad4)
        Me.Controls.Add(Me.NumPad0)
        Me.Controls.Add(Me.NumPad2)
        Me.Controls.Add(Me.NumPad5)
        Me.Controls.Add(Me.Decimall)
        Me.Controls.Add(Me.NumPad3)
        Me.Controls.Add(Me.NumPad6)
        Me.Controls.Add(Me.Add)
        Me.Controls.Add(Me.NumPad9)
        Me.Controls.Add(Me.NumPad8)
        Me.Controls.Add(Me.NumPad7)
        Me.Controls.Add(Me.Subtract)
        Me.Controls.Add(Me.Multiply)
        Me.Controls.Add(Me.Divide)
        Me.Controls.Add(Me.NumLock)
        Me.Controls.Add(Me.Space)
        Me.Controls.Add(Me.LWin)
        Me.Controls.Add(Me.LMenu)
        Me.Controls.Add(Me.RMenu)
        Me.Controls.Add(Me.RWin)
        Me.Controls.Add(Me.Apps)
        Me.Controls.Add(Me.RControlKey)
        Me.Controls.Add(Me.Right)
        Me.Controls.Add(Me.Down)
        Me.Controls.Add(Me.Left)
        Me.Controls.Add(Me.Up)
        Me.Controls.Add(Me.LControlKey)
        Me.Controls.Add(Me.LShiftKey)
        Me.Controls.Add(Me.OemBackslash)
        Me.Controls.Add(Me.W)
        Me.Controls.Add(Me.X)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.V)
        Me.Controls.Add(Me.B)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Oemcomma)
        Me.Controls.Add(Me.OemPeriod)
        Me.Controls.Add(Me.OemQuestion)
        Me.Controls.Add(Me.Oem8)
        Me.Controls.Add(Me.Capital)
        Me.Controls.Add(Me.Q)
        Me.Controls.Add(Me.S)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.F)
        Me.Controls.Add(Me.G)
        Me.Controls.Add(Me.H)
        Me.Controls.Add(Me.J)
        Me.Controls.Add(Me.K)
        Me.Controls.Add(Me.L)
        Me.Controls.Add(Me.Oemtilde)
        Me.Controls.Add(Me.M)
        Me.Controls.Add(Me.Tab)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.Z)
        Me.Controls.Add(Me.E)
        Me.Controls.Add(Me.R)
        Me.Controls.Add(Me.T)
        Me.Controls.Add(Me.Y)
        Me.Controls.Add(Me.U)
        Me.Controls.Add(Me.I)
        Me.Controls.Add(Me.O)
        Me.Controls.Add(Me.P)
        Me.Controls.Add(Me.Oem6)
        Me.Controls.Add(Me.Oem5)
        Me.Controls.Add(Me.Oem1)
        Me.Controls.Add(Me.RShiftKey)
        Me.Controls.Add(Me.ReturnBig)
        Me.Controls.Add(Me.Nextt)
        Me.Controls.Add(Me.PageUp)
        Me.Controls.Add(Me.Endd)
        Me.Controls.Add(Me.Home)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.Insert)
        Me.Controls.Add(Me.Back)
        Me.Controls.Add(Me.Oemplus)
        Me.Controls.Add(Me.OemOpenBrackets)
        Me.Controls.Add(Me.D0)
        Me.Controls.Add(Me.D9)
        Me.Controls.Add(Me.D8)
        Me.Controls.Add(Me.D7)
        Me.Controls.Add(Me.D6)
        Me.Controls.Add(Me.D5)
        Me.Controls.Add(Me.D4)
        Me.Controls.Add(Me.D3)
        Me.Controls.Add(Me.D2)
        Me.Controls.Add(Me.D1)
        Me.Controls.Add(Me.Oem7)
        Me.Controls.Add(Me.Pause)
        Me.Controls.Add(Me.Scroll)
        Me.Controls.Add(Me.PrintScreen)
        Me.Controls.Add(Me.F12)
        Me.Controls.Add(Me.F11)
        Me.Controls.Add(Me.F10)
        Me.Controls.Add(Me.F9)
        Me.Controls.Add(Me.F8)
        Me.Controls.Add(Me.F7)
        Me.Controls.Add(Me.F6)
        Me.Controls.Add(Me.F5)
        Me.Controls.Add(Me.F4)
        Me.Controls.Add(Me.F3)
        Me.Controls.Add(Me.F2)
        Me.Controls.Add(Me.F1)
        Me.Controls.Add(Me.Escape)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Keyboard"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Escape As Button
    Friend WithEvents F1 As Button
    Friend WithEvents F2 As Button
    Friend WithEvents F4 As Button
    Friend WithEvents F3 As Button
    Friend WithEvents F8 As Button
    Friend WithEvents F7 As Button
    Friend WithEvents F6 As Button
    Friend WithEvents F5 As Button
    Friend WithEvents F12 As Button
    Friend WithEvents F11 As Button
    Friend WithEvents F10 As Button
    Friend WithEvents F9 As Button
    Friend WithEvents Pause As Button
    Friend WithEvents Scroll As Button
    Friend WithEvents PrintScreen As Button
    Friend WithEvents Oem7 As Button
    Friend WithEvents D1 As Button
    Friend WithEvents D2 As Button
    Friend WithEvents D3 As Button
    Friend WithEvents D4 As Button
    Friend WithEvents D5 As Button
    Friend WithEvents D6 As Button
    Friend WithEvents D7 As Button
    Friend WithEvents D8 As Button
    Friend WithEvents D9 As Button
    Friend WithEvents D0 As Button
    Friend WithEvents OemOpenBrackets As Button
    Friend WithEvents Oemplus As Button
    Friend WithEvents Back As Button
    Friend WithEvents Insert As Button
    Friend WithEvents Delete As Button
    Friend WithEvents Endd As Button
    Friend WithEvents Home As Button
    Friend WithEvents PageUp As Button
    Friend WithEvents Nextt As Button
    Friend WithEvents ReturnBig As Button
    Friend WithEvents RShiftKey As Button
    Friend WithEvents Oem1 As Button
    Friend WithEvents Oem5 As Button
    Friend WithEvents Oem6 As Button
    Friend WithEvents P As Button
    Friend WithEvents O As Button
    Friend WithEvents I As Button
    Friend WithEvents U As Button
    Friend WithEvents Y As Button
    Friend WithEvents T As Button
    Friend WithEvents R As Button
    Friend WithEvents E As Button
    Friend WithEvents Z As Button
    Friend WithEvents A As Button
    Friend WithEvents Tab As Button
    Friend WithEvents M As Button
    Friend WithEvents Oemtilde As Button
    Friend WithEvents L As Button
    Friend WithEvents K As Button
    Friend WithEvents J As Button
    Friend WithEvents H As Button
    Friend WithEvents G As Button
    Friend WithEvents F As Button
    Friend WithEvents D As Button
    Friend WithEvents S As Button
    Friend WithEvents Q As Button
    Friend WithEvents Capital As Button
    Friend WithEvents Oem8 As Button
    Friend WithEvents OemQuestion As Button
    Friend WithEvents OemPeriod As Button
    Friend WithEvents Oemcomma As Button
    Friend WithEvents N As Button
    Friend WithEvents B As Button
    Friend WithEvents V As Button
    Friend WithEvents C As Button
    Friend WithEvents X As Button
    Friend WithEvents W As Button
    Friend WithEvents OemBackslash As Button
    Friend WithEvents LShiftKey As Button
    Friend WithEvents LControlKey As Button
    Friend WithEvents Up As Button
    Friend WithEvents Left As Button
    Friend WithEvents Down As Button
    Friend WithEvents Right As Button
    Friend WithEvents RControlKey As Button
    Friend WithEvents Apps As Button
    Friend WithEvents RWin As Button
    Friend WithEvents RMenu As Button
    Friend WithEvents LMenu As Button
    Friend WithEvents LWin As Button
    Friend WithEvents Space As Button
    Friend WithEvents NumLock As Button
    Friend WithEvents Divide As Button
    Friend WithEvents Multiply As Button
    Friend WithEvents Subtract As Button
    Friend WithEvents NumPad7 As Button
    Friend WithEvents NumPad8 As Button
    Friend WithEvents NumPad9 As Button
    Friend WithEvents Add As Button
    Friend WithEvents NumPad6 As Button
    Friend WithEvents NumPad3 As Button
    Friend WithEvents Decimall As Button
    Friend WithEvents NumPad5 As Button
    Friend WithEvents NumPad2 As Button
    Friend WithEvents NumPad0 As Button
    Friend WithEvents NumPad4 As Button
    Friend WithEvents NumPad1 As Button
    Friend WithEvents Returnn As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents LeftMouseButton As Button
    Friend WithEvents RightMouseButton As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents WheelButtonUp As Button
    Friend WithEvents WheelButtonDown As Button
    Friend WithEvents CheckBox1 As CheckBox
End Class
